package com.clw.bluetooth.app;

import com.clw.bluetooth.bean.ProductBean;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class App extends Application {
  private static final String TAG = "App";

  private static SharedPreferences sp = null;

  /** 获取机台号 */
  public static String getMachineNo(Context mContext) {
    sp = mContext.getSharedPreferences("machine_no", MODE_PRIVATE);
    String no = sp.getString("no", "");
    return no;

  }
  
  /** 装配单数据保存本地*/
//  public static void saveProduct(Context mContext,ProductBean bean){
//    SharedPreferences sp=mContext.getSharedPreferences("product", MODE_PRIVATE);
//    Editor ed=sp.edit();
//    ed.putString("", arg1);
//  }
}
