package com.clw.bluetooth.util;

import java.util.Comparator;
import java.util.List;
import java.util.Map;

import com.clw.bluetooth.bean.ProCodeBean;
import com.clw.bluetooth.bean.ProductBean;

public class ArrayListSort implements Comparator<ProCodeBean>{
  private static final String TAG = "ArrayListSort";

  @Override
  public int compare(ProCodeBean arg0, ProCodeBean arg1) {
    return 0;
  }


}
