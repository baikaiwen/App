package com.clw.bluetooth.bean;

public class ProCodeBean {
  private static final String TAG = "ProCodeBean";
  
  private int no;
  private String code;
  public int getNo() {
    return this.no;
  }
  public void setNo(int no) {
    this.no = no;
  }
  public String getCode() {
    return this.code;
  }
  public void setCode(String code) {
    this.code = code;
  }
  
  
}
