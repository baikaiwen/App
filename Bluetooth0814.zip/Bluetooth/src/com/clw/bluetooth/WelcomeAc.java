package com.clw.bluetooth;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.clw.bluetooth.app.App;
import com.clw.bluetooth.bean.ProductBean;
import com.clw.bluetooth.bean.ReviewProductBean;
import com.clw.bluetooth.pop.ChoiceDatePop;
import com.clw.bluetooth.pop.ChoiceDatePop.GetDateListener;
import com.clw.bluetooth.service.BluetoothService;
import com.clw.bluetooth.service.NetService;
import com.clw.bluetooth.util.BtSPP;
import com.clw.bluetooth.util.StaticField;
import com.clw.bluetooth.util.Tools;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.TextView.OnEditorActionListener;

public class WelcomeAc extends Activity implements OnClickListener {
  private static final String TAG = "WelcomeAc";

  private Context mContext = null;

  /** 选择器 */
  private ChoiceDatePop mChoiceDatePop;

  private TextView tv_time;

  /** 机台号输入框 */
  private EditText et_input;

  /** 条形码输入框 */
  private EditText et_scan;

  /** 日期 */
  private String date = "";

  /** 保存机台号到本地 */
  private SharedPreferences sp_machine_no = null;

  private SharedPreferences sp_json = null;

  /** 机台号 */
  private String machine = "";

  /** 扫描得到的单据条码 */
  private String strCode = "";

  /** 数据 */
  private List<ReviewProductBean> productBeans = new ArrayList<ReviewProductBean>();

  /** 流水号 */
  private int serialNum = 100001;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.ac_welcome);
    mContext = WelcomeAc.this;
    initView();

  }

  /**
   * 初始化
   * */
  private void initView() {
    et_input = (EditText) findViewById(R.id.et_input);
    et_scan = (EditText) findViewById(R.id.et_scan);
    tv_time = (TextView) findViewById(R.id.tv_time);
    tv_time.setOnClickListener(this);

    /* 首选项 */
    sp_machine_no = getSharedPreferences("machine_no", MODE_PRIVATE);
    String no = App.getMachineNo(mContext);
    if (!Tools.isNull(no)) {
      et_input.setText(no);
      // startActivity(new Intent(mContext, MainAc.class));
    }
    et_scan.setOnEditorActionListener(new EditorListener());
  }

  @Override
  protected void onResume() {
    super.onResume();
    sp_json = getSharedPreferences("jsonCache", MODE_APPEND);
    String json = sp_json.getString("json", "");
    loadLocal(json);
  }

  /**
   * 加载本地json
   * 
   * */
  private void loadLocal(String json) {
    try {
      JSONObject obj = new JSONObject(json);
      String stat = obj.getString("status");
      if (Tools.judgeStringEquals("0", stat)) {
        JSONArray array = obj.getJSONArray("data");
        for (int i = 0; i < array.length(); i++) {
          ReviewProductBean bean = new ReviewProductBean();
          bean.setBwNo(array.getJSONObject(i).getString("f_bw_no"));
          bean.setQty(array.getJSONObject(i).getString("f_qty"));
          productBeans.add(bean);
        }
      }
    } catch (JSONException e) {
      Log.e(TAG, "", e);
    }

  }

  /**
   * 条形码输入监听
   * 
   * */
  private class EditorListener implements OnEditorActionListener {

    @Override
    public boolean onEditorAction(TextView arg0, int arg1, KeyEvent arg2) {
      if (arg1 == EditorInfo.IME_ACTION_SEARCH) {
        strCode = et_input.getText().toString();
      }
      return true;
    }

  }

  /**
   * 点击事件监听
   * */
  @Override
  public void onClick(View arg0) {
    switch (arg0.getId()) {
      case R.id.tv_time:
        showDate(tv_time);
        break;

      default:
        break;
    }
  };

  /**
   * pop监听
   */
  GetDateListener mGetDateListener = new GetDateListener() {

    @Override
    public void getTime(String startTime, String endTime) {
      tv_time.setText(startTime);
    }
  };

  /**
   * 按键事件监听 数字键1A: keycode=204; //重新打印上次数据
   * */
  public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
    switch (keyCode) {
      case KeyEvent.KEYCODE_TAB: // 按下tab键时判断机台号与单据条码是否为空
        // date=tv_time.getText().toString();
        machine = et_input.getText().toString();
        strCode = et_scan.getText().toString();
        if (!Tools.isNull(machine, strCode)) {
          NetService.getInstance().getFristData(strCode, handler);
          Editor ed = sp_machine_no.edit();
          ed.clear();
          ed.putString("no", machine);
          ed.commit();

        } else {
          Toast.makeText(mContext, "请输入机台号", Toast.LENGTH_LONG);
        }
        break;
      case 204: // 重新打印
        if (!Tools.isNull(StaticField.blueAddress)) {
          Print1(StaticField.blueAddress);
        } else {
          Toast.makeText(mContext, "您还没有进行商品复核!", Toast.LENGTH_SHORT).show();
        }
        break;
      default:
        break;
    }
    return super.onKeyDown(keyCode, event);
  }

  /**
   * 网络请求Handler消息处理
   * 
   * */
  Handler handler = new Handler() {
    public void handleMessage(android.os.Message msg) {
      switch (msg.arg1) {
        case 1:
          et_scan.getText().clear();
          startActivity(new Intent(mContext, MainAc.class).putExtra("jt_no", machine));
          Log.i(TAG, "线路:" + ProductBean.getInstance().getLine() + ",客户:" + ProductBean.getInstance().getCustmo()
              + ",摊位:" + ProductBean.getInstance().getBooth());
          break;
        case 0:
          Toast.makeText(mContext, "网络错误", 200).show();
          break;
        default:
          break;
      }
    };
  };

  private void showDate(TextView tv) {
    if (null == mChoiceDatePop) {
      mChoiceDatePop = new ChoiceDatePop(this, mGetDateListener);
    }
    mChoiceDatePop.show(tv);
  }

  /***
   * 打印操作
   * */
  public void Print1(String BDAddress) {
    if (!BtSPP.OpenPrinter(BDAddress)) {
      Toast.makeText(this, BtSPP.ErrorMessage, Toast.LENGTH_SHORT).show();
      return;
    }
    try {
      BtSPP.SPPWrite(new byte[] { 0x1B, 0x40 }); // 打印机复位
      BtSPP.SPPWrite(new byte[] { 0x1B, 0x33, 0x00 }); // 设置行间距为0
      BtSPP.SPPWrite("\n".getBytes("GBK"));
      BtSPP.SPPWrite(new byte[] { 0x1B, 0x61, 0x01 }); // 设置不居中 1居中0不居中
      BtSPP.SPPWrite(new byte[] { 0x1d, 0x21, 0x00 }); // 设置倍高 1倍高0不倍高
      BtSPP.SPPWrite(String.format("客户:%-16s\n", ProductBean.getInstance().getCustmo()).getBytes("GBK"));
      // BtSPP.SPPWrite("\n".getBytes("GBK"));
      // BtSPP.SPPWrite(new byte[] { 0x1B, 0x61, 0x01 }); // 设置不居中 1居中0不居中
      BtSPP.SPPWrite(String.format(" 摊位:%-16s", ProductBean.getInstance().getBooth()).getBytes("GBK"));
      BtSPP.SPPWrite("\n".getBytes("GBK"));
      BtSPP.SPPWrite(new byte[] { 0x1d, 0x48, 0x02 }); // 设置条码内容打印在条码下方
      BtSPP.SPPWrite(new byte[] { 0x1d, 0x77, 0x08 }); // 设置条码宽度0.375
      BtSPP.SPPWrite(new byte[] { 0x1d, 0x68, 0x40 }); // 设置条码高度64
      // 打印code128条码
      BtSPP.SPPWrite(new byte[] { 0x1D, 0x6B, 0x18 });
      /* 对日期进行处理 */
      String date = ProductBean.getInstance().getDate();
      String dateStr = date.replace("-", "");
      BtSPP.SPPWrite((dateStr + machine + (serialNum++) + "\0\n").getBytes("GBK"));// 条码字符串
      BtSPP.SPPWrite("                \n".getBytes("GBK"));
      // BtSPP.SPPWrite(String.format("流水号: %6d\n",
      // serialNum++).getBytes("GBK")); //流水号
      int no = 1;
      for (int i = 0; i < productBeans.size(); i++) {
        BtSPP.SPPWrite(String.format((no++) + ".%-16s 数量:%-16s\n", productBeans.get(i).getBwNo(),
            productBeans.get(i).getQty()).getBytes("GBK"));
      }
      // BtSPP.SPPWrite(new byte[] { 0x1d, 0x21, 0x00 }); // 设置不倍高
      // BtSPP.SPPWrite(new byte[] { 0x1b, 0x61, 0x01 }); // 设置居中
      // BtSPP.SPPWrite(new byte[] { 0x1d, 0x21, 0x01 }); // 设置倍高
      // BtSPP.SPPWrite(String.format("日期：%10s\n", date).getBytes("GBK"));

      // BtSPP.SPPWrite("\n\n\n".getBytes("GBK"));
    } catch (UnsupportedEncodingException e) {
    }

    BtSPP.SPPClose();
  }

}
